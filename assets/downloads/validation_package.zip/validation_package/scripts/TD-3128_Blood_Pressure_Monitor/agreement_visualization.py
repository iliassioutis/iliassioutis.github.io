import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Load the Excel file
file_path = "BloodPressurePulseRate_Validation.xlsx"
df = pd.read_excel(file_path, sheet_name="BloodPressurePulseRateData")

# Rename columns to make them easier to reference in the script
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Systolic 1 (mmHg)": "Systolic_1",
    "Systolic 2 (mmHg)": "Systolic_2",
    "Systolic 3 (mmHg)": "Systolic_3",
    "Diastolic 1 (mmHg)": "Diastolic_1",
    "Diastolic 2 (mmHg)": "Diastolic_2",
    "Diastolic 3 (mmHg)": "Diastolic_3",
    "Pulse 1 (bpm)": "Pulse_1",
    "Pulse 2 (bpm)": "Pulse_2",
    "Pulse 3 (bpm)": "Pulse_3",
})

# Define clinically acceptable variation ranges
bp_threshold = 5  # ±5 mmHg for systolic and diastolic
pulse_threshold = 3  # ±3 bpm for pulse

# Function to compute agreement percentage per participant
def compute_agreement(df, measurement, threshold):
    agreements = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold) & 
                  (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold) & 
                  (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold)).sum()
    
    total = len(df)  # Total participants
    return (agreements / total) * 100  # Return the agreement percentage

# Compute agreement per participant for each measurement
systolic_agreement_percent = compute_agreement(df, "Systolic", bp_threshold)
diastolic_agreement_percent = compute_agreement(df, "Diastolic", bp_threshold)
pulse_agreement_percent = compute_agreement(df, "Pulse", pulse_threshold)

# Data for visualization
labels = ["Systolic BP", "Diastolic BP", "Pulse Rate"]
agreement_values = [systolic_agreement_percent, diastolic_agreement_percent, pulse_agreement_percent]

# Create a bar chart
plt.figure(figsize=(8, 5))
plt.bar(labels, agreement_values, color=['royalblue', 'seagreen', 'darkorange'], edgecolor='black')
plt.ylim(0, 100)
plt.ylabel("Agreement Percentage (%)")
plt.title("Agreement Percentage Across Participants")
plt.grid(axis="y", linestyle="--", alpha=0.7)

# Add text labels on bars
for i, value in enumerate(agreement_values):
    plt.text(i, value + 2, f"{value:.2f}%", ha='center', fontsize=12, fontweight='bold')

# Save and display the chart
plt.savefig("Agreement_Percentage_Participants.png")
plt.show()
