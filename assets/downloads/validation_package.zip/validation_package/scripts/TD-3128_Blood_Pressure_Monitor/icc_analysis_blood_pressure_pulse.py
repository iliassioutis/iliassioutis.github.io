import pandas as pd
import pingouin as pg

# Load the dataset from the Excel file
file_path = "BloodPressurePulseRate_Validation.xlsx"
sheet_name = "BloodPressurePulseRateData"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency (removing spaces and special characters)
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Systolic 1 (mmHg)": "Systolic_1", "Systolic 2 (mmHg)": "Systolic_2", "Systolic 3 (mmHg)": "Systolic_3",
    "Diastolic 1 (mmHg)": "Diastolic_1", "Diastolic 2 (mmHg)": "Diastolic_2", "Diastolic 3 (mmHg)": "Diastolic_3",
    "Pulse 1 (bpm)": "Pulse_1", "Pulse 2 (bpm)": "Pulse_2", "Pulse 3 (bpm)": "Pulse_3"
})

# Function to reshape data for ICC analysis
def prepare_icc_data(df, measurement_name):
    """
    Reshapes the dataset for ICC computation by converting repeated measures into a long format.
    Extracts the measurement number for proper ICC structuring.
    """
    icc_data = pd.melt(df, id_vars=["Participant_ID"], 
                       value_vars=[f"{measurement_name}_1", f"{measurement_name}_2", f"{measurement_name}_3"],
                       var_name="Measurement", value_name="Value")
    
    # Extract measurement number (1, 2, or 3)
    icc_data["Measurement"] = icc_data["Measurement"].str.extract(r'(\d)').astype(int)
    
    return icc_data

# Function to compute ICC
def compute_icc(df, measurement_name):
    """
    Computes the Intraclass Correlation Coefficient (ICC) for repeated measurements.
    """
    icc_data = prepare_icc_data(df, measurement_name)
    icc_result = pg.intraclass_corr(data=icc_data, targets='Participant_ID', raters='Measurement', ratings='Value')
    return icc_result

# Compute ICC for Systolic, Diastolic, and Pulse
icc_systolic = compute_icc(df, "Systolic")
icc_diastolic = compute_icc(df, "Diastolic")
icc_pulse = compute_icc(df, "Pulse")

# Display results
print("✅ Intraclass Correlation Coefficient (ICC) Results:")
print("\n📌 Systolic Blood Pressure ICC:\n", icc_systolic)
print("\n📌 Diastolic Blood Pressure ICC:\n", icc_diastolic)
print("\n📌 Pulse ICC:\n", icc_pulse)
