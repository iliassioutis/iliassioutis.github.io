import matplotlib.pyplot as plt
import numpy as np

# ICC values for Diastolic Blood Pressure
icc_types = [
    "Single Measure (ICC1)", "Single Random (ICC2)", "Single Fixed (ICC3)",
    "Avg Measure (ICC1k)", "Avg Random (ICC2k)", "Avg Fixed (ICC3k)"
]

icc_values = [0.9800, 0.9800, 0.9798, 0.9933, 0.9933, 0.9932]  # ICC values from analysis
ci_lower = [0.96, 0.96, 0.96, 0.99, 0.99, 0.99]  # Lower bound of CI
ci_upper = [0.99, 0.99, 0.99, 1.00, 1.00, 1.00]  # Upper bound of CI

# Convert lists to NumPy arrays for calculations
icc_values = np.array(icc_values)
ci_lower = np.array(ci_lower)
ci_upper = np.array(ci_upper)

# Compute error bars
errors = np.abs(np.array([
    icc_values - ci_lower,  # Difference between ICC and lower CI
    ci_upper - icc_values   # Difference between ICC and upper CI
]))

# Define y-axis positions
y_pos = np.arange(len(icc_types))

# Create the horizontal bar chart
plt.figure(figsize=(10, 6))
plt.barh(y_pos, icc_values, xerr=errors, align='center', alpha=0.7, capsize=5,
         color='royalblue', edgecolor='black')

plt.yticks(y_pos, icc_types)
plt.xlabel("Intraclass Correlation Coefficient (ICC)")
plt.title("Reliability Analysis of Diastolic Blood Pressure Measurements (TD-3128)")
plt.xlim(0.85, 1.0)  # Focus range for ICC values

# Add grid and threshold line
plt.grid(axis='x', linestyle='--', alpha=0.6)
plt.axvline(x=0.90, color='red', linestyle='--', label="Excellent Reliability Threshold")
plt.legend()

# Save the plot
plt.savefig("ICC_Diastolic_BloodPressure.png", dpi=300, bbox_inches='tight')

# Display the plot
plt.show()

print("✅ ICC Diastolic Blood Pressure Bar Chart saved as 'ICC_Diastolic_BloodPressure.png'")
