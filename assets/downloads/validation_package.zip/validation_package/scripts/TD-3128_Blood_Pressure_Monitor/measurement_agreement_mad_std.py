import pandas as pd
import numpy as np

# Load the Excel file
file_path = "BloodPressurePulseRate_Validation.xlsx"
df = pd.read_excel(file_path, sheet_name="BloodPressurePulseRateData")

# Rename columns to make them easier to reference in the script
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Systolic 1 (mmHg)": "Systolic_1",
    "Systolic 2 (mmHg)": "Systolic_2",
    "Systolic 3 (mmHg)": "Systolic_3",
    "Diastolic 1 (mmHg)": "Diastolic_1",
    "Diastolic 2 (mmHg)": "Diastolic_2",
    "Diastolic 3 (mmHg)": "Diastolic_3",
    "Pulse 1 (bpm)": "Pulse_1",
    "Pulse 2 (bpm)": "Pulse_2",
    "Pulse 3 (bpm)": "Pulse_3",
})

# Define clinically acceptable variation ranges
bp_threshold = 5  # ±5 mmHg for systolic and diastolic
pulse_threshold = 3  # ±3 bpm for pulse

# Function to compute agreement percentage, Mean Absolute Difference (MAD), and Standard Deviation of Errors
def compute_agreement_mad_std(df, measurement, threshold):
    agreements = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold) & 
                  (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold) & 
                  (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold)).sum()
    
    total = len(df)  # Total participants
    agreement_percentage = (agreements / total) * 100

    # MAD calculation: compute per participant first, then take the overall mean
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3  # Per participant MAD

    mean_absolute_diff = mad_per_participant.mean()  # Final MAD across all participants

    # Standard deviation of errors per participant
    std_dev_errors = mad_per_participant.std()  # Standard deviation of MAD values

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute agreement, MAD, and standard deviation for each measurement
systolic_agreement, systolic_mad, systolic_std_dev = compute_agreement_mad_std(df, "Systolic", bp_threshold)
diastolic_agreement, diastolic_mad, diastolic_std_dev = compute_agreement_mad_std(df, "Diastolic", bp_threshold)
pulse_agreement, pulse_mad, pulse_std_dev = compute_agreement_mad_std(df, "Pulse", pulse_threshold)

# Print results
print("Measurement Agreement Results:")
print(f"Systolic BP Agreement: {systolic_agreement:.2f}% | MAD: {systolic_mad:.2f} mmHg | Std Dev: {systolic_std_dev:.2f} mmHg")
print(f"Diastolic BP Agreement: {diastolic_agreement:.2f}% | MAD: {diastolic_mad:.2f} mmHg | Std Dev: {diastolic_std_dev:.2f} mmHg")
print(f"Pulse Rate Agreement: {pulse_agreement:.2f}% | MAD: {pulse_mad:.2f} bpm | Std Dev: {pulse_std_dev:.2f} bpm")
