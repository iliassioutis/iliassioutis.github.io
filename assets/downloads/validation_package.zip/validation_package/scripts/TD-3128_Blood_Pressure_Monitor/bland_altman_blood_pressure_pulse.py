import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = "BloodPressurePulseRate_Validation"
sheet_name = "TaiDoc_vs_GoldStandard"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Prepare storage for Bland-Altman statistical results
results = []

# Function to generate Bland-Altman plots and save them
def bland_altman_plot(measurement, title, save_path, unit="mmHg"):
    """
    Generates a Bland-Altman plot, prints key statistics, and saves the plot.
    """
    # Handle unit differences for Pulse Rate (bpm instead of mmHg)
    if measurement == "Pulse":
        unit = "bpm"

    # Compute the means and differences for the first measurement
    mean_values = (df[f'TaiDoc {measurement} 1 ({unit})'] + df[f'Gold Standard {measurement} 1 ({unit})']) / 2
    differences = df[f'TaiDoc {measurement} 1 ({unit})'] - df[f'Gold Standard {measurement} 1 ({unit})']

    # Repeat for second and third readings
    for i in [2, 3]:
        mean = (df[f'TaiDoc {measurement} {i} ({unit})'] + df[f'Gold Standard {measurement} {i} ({unit})']) / 2
        diff = df[f'TaiDoc {measurement} {i} ({unit})'] - df[f'Gold Standard {measurement} {i} ({unit})']
        
        mean_values = pd.concat([mean_values, pd.Series(mean)], ignore_index=True)
        differences = pd.concat([differences, pd.Series(diff)], ignore_index=True)

    # Compute mean and limits of agreement (LOA)
    mean_diff = np.mean(differences)
    std_diff = np.std(differences, ddof=1)  # Standard deviation with degrees of freedom = 1
    loa_upper = mean_diff + 1.96 * std_diff
    loa_lower = mean_diff - 1.96 * std_diff

    # Print Bland-Altman statistics
    print(f"\nBland-Altman Analysis for {title}:")
    print(f"Mean Difference: {mean_diff:.2f} {unit}")
    print(f"Standard Deviation: {std_diff:.2f} {unit}")
    print(f"Upper Limit of Agreement (LOA): {loa_upper:.2f} {unit}")
    print(f"Lower Limit of Agreement (LOA): {loa_lower:.2f} {unit}")

    # Store results for saving later
    results.append({
        "Measurement": title,
        f"Mean Difference ({unit})": mean_diff,
        f"Standard Deviation ({unit})": std_diff,
        f"Upper LOA ({unit})": loa_upper,
        f"Lower LOA ({unit})": loa_lower
    })

    # Plot
    plt.figure(figsize=(8, 6))
    sns.scatterplot(x=mean_values, y=differences, alpha=0.7)
    plt.axhline(mean_diff, color='red', linestyle='--', label=f'Mean Diff: {mean_diff:.2f} {unit}')
    plt.axhline(loa_upper, color='blue', linestyle='--', label=f'Upper LOA: {loa_upper:.2f} {unit}')
    plt.axhline(loa_lower, color='blue', linestyle='--', label=f'Lower LOA: {loa_lower:.2f} {unit}')
    
    plt.xlabel(f'Mean of TaiDoc & Gold Standard {title} ({unit})')
    plt.ylabel(f'Difference (TaiDoc - Gold Standard) ({unit})')
    plt.title(f'Bland-Altman Plot for {title}')
    plt.legend()
    plt.grid(True)
    
    # Save the plot
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved as: {save_path}")
    
    plt.close()  # Close the plot to prevent display issues

# Generate and save Bland-Altman Plots
bland_altman_plot("Systolic", "Systolic Blood Pressure", "BlandAltman_Systolic.png", "mmHg")
bland_altman_plot("Diastolic", "Diastolic Blood Pressure", "BlandAltman_Diastolic.png", "mmHg")
bland_altman_plot("Pulse", "Pulse Rate", "BlandAltman_Pulse.png", "bpm")

# Save the statistical results to a CSV file
results_df = pd.DataFrame(results)
results_df.to_csv("BlandAltman_Results.csv", index=False)
print("\nBland-Altman statistical results saved as 'BlandAltman_Results.csv'")
