import matplotlib.pyplot as plt
import numpy as np

# Labels for measurements
measurement_types = ["Systolic BP", "Diastolic BP", "Pulse Rate"]

# ICC3 and ICC3k values for single and averaged measurements
icc_3 = [0.9831, 0.9798, 0.9799]  # ICC3 for single measurement (fixed raters)
icc_3k = [0.9943, 0.9932, 0.9932]  # ICC3k for averaged measurement (fixed raters)

# Positioning for bars
x = np.arange(len(measurement_types))
width = 0.35  # Width of bars

# Create the bar chart
fig, ax = plt.subplots(figsize=(10, 6))
bars1 = ax.bar(x - width/2, icc_3, width, label="ICC3 (Single Fixed Raters)", color="royalblue", edgecolor='black')
bars2 = ax.bar(x + width/2, icc_3k, width, label="ICC3k (Averaged Measurements)", color="seagreen", edgecolor='black')

# Labels and title
ax.set_xlabel("Measurement Type")
ax.set_ylabel("Intraclass Correlation Coefficient (ICC)")
ax.set_title("Comparison of ICC3 and ICC3k for Blood Pressure & Pulse Rate")
ax.set_xticks(x)
ax.set_xticklabels(measurement_types)
ax.set_ylim(0.85, 1.0)  # Focus range for ICC values
ax.legend()

# Add grid and threshold line
ax.axhline(y=0.90, color='red', linestyle='--', label="Excellent Reliability Threshold")
ax.grid(axis='y', linestyle='--', alpha=0.6)

# Save and show the chart
plt.savefig("ICC_Comparison_BloodPressure_Pulse.png", dpi=300, bbox_inches='tight')
plt.show()

print("✅ ICC Comparison Chart saved as 'ICC_Comparison_BloodPressure_Pulse.png'")
