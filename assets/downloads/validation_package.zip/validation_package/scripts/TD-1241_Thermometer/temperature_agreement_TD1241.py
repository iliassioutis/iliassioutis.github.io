import pandas as pd
import numpy as np

# Load the dataset
file_path = "Forehead_Temperature_Validation.xlsx"
sheet_name = "TD-1241_Temp_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Temp 1 (°C)": "Temp_1",
    "Temp 2 (°C)": "Temp_2",
    "Temp 3 (°C)": "Temp_3",
})

# Define the dynamic threshold functions based on manufacturer claims
def dynamic_temp_threshold(value):
    """Dynamic threshold for temperature based on manufacturer accuracy claims."""
    if 36.0 <= value <= 39.0:
        return 0.21  # Adjusted to prevent rounding errors (was 0.2)
    else:
        return 0.31  # Adjusted to prevent rounding errors (was 0.3)

# Function to compute agreement percentage, MAD, and standard deviation of errors
def compute_metrics(df, measurement, threshold_func):
    threshold_1 = df[f"{measurement}_1"].apply(threshold_func)
    threshold_2 = df[f"{measurement}_2"].apply(threshold_func)
    threshold_3 = df[f"{measurement}_3"].apply(threshold_func)

    # Compute per-participant agreement
    df[f"{measurement}_Agreement"] = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold_1) & 
                                      (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold_2) & 
                                      (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold_3))

    # Compute the overall agreement percentage
    agreement_percentage = (df[f"{measurement}_Agreement"].sum() / len(df)) * 100

    # MAD calculation (Mean Absolute Difference per participant)
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3

    mean_absolute_diff = mad_per_participant.mean()  # Final MAD across all participants
    std_dev_errors = mad_per_participant.std()  # Standard deviation of MAD values

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute metrics for Temperature using the manufacturer's accuracy threshold
temp_agreement, temp_mad, temp_std_dev = compute_metrics(df, "Temp", dynamic_temp_threshold)

# 🔹 Print results
print("\n✅ Measurement Agreement Results (Using Manufacturer's Accuracy Threshold for Temperature):")
print(f"Temperature Agreement: {temp_agreement:.2f}%")
print(f"Mean Absolute Difference (MAD): {temp_mad:.2f}°C")
print(f"Standard Deviation of Errors: {temp_std_dev:.2f}°C")
