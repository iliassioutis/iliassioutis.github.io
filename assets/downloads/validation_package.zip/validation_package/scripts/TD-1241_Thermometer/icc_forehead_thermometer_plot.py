import matplotlib.pyplot as plt
import numpy as np

# ICC values for Forehead Temperature (TD-1241)
icc_types = [
    "Single Measure (ICC1)", "Single Random (ICC2)", "Single Fixed (ICC3)",
    "Avg Measure (ICC1k)", "Avg Random (ICC2k)", "Avg Fixed (ICC3k)"
]

icc_values = [0.975251, 0.975252, 0.975305, 0.991612, 0.991612, 0.991631]  # ICC values from output
ci_lower = [0.95, 0.95, 0.95, 0.98, 0.98, 0.98]  # Lower bound of CI
ci_upper = [0.99, 0.99, 0.99, 1.0, 1.0, 1.0]  # Upper bound of CI

# Convert lists to NumPy arrays for calculations
y_pos = np.arange(len(icc_types))
icc_values = np.array(icc_values)
ci_lower = np.array(ci_lower)
ci_upper = np.array(ci_upper)

# Error bars
errors = np.abs(np.array([
    icc_values - ci_lower,  # Difference between ICC and lower CI
    ci_upper - icc_values   # Difference between ICC and upper CI
]))

# Create the horizontal bar chart
plt.figure(figsize=(10, 6))
plt.barh(y_pos, icc_values, xerr=errors, align='center', alpha=0.7, capsize=5,
         color='royalblue', edgecolor='black')

plt.yticks(y_pos, icc_types)
plt.xlabel("Intraclass Correlation Coefficient (ICC)")
plt.title("Reliability Analysis of Forehead Temperature Measurements (TD-1241)")
plt.xlim(0.85, 1.0)  # Focus range for ICC values

# Add grid and threshold line
plt.grid(axis='x', linestyle='--', alpha=0.6)
plt.axvline(x=0.90, color='red', linestyle='--', label="Excellent Reliability Threshold")
plt.legend()

# Save and display the chart
plt.savefig("ICC_Temperature_TD1241.png", dpi=300, bbox_inches='tight')
plt.show()

print("✅ ICC Temperature Bar Chart saved as 'ICC_Temperature_TD1241.png'")
