import pandas as pd
import numpy as np

# Load the dataset
file_path = "ECG_Validation_PM10.xlsx"
sheet_name = "PM10_ECG_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "HR 1 (bpm)": "HR_1",
    "HR 2 (bpm)": "HR_2",
    "HR 3 (bpm)": "HR_3",
})

# Define the dynamic threshold function based on manufacturer claims
def dynamic_hr_threshold(value):
    """Dynamic threshold for Heart Rate based on manufacturer accuracy claims."""
    return max(1, value * 0.01)  # ±1 bpm or ±1% of the reading, whichever is greater

# Define a clinically acceptable threshold for HR (Fixed ±3 bpm threshold)
def clinical_hr_threshold(value):
    """Sets a clinically acceptable threshold for Heart Rate (±3 bpm)."""
    return 3  # Fixed ±3 bpm threshold

# Function to compute agreement percentage, MAD, and standard deviation of errors
def compute_metrics(df, measurement, threshold_func):
    threshold_1 = df[f"{measurement}_1"].apply(threshold_func)
    threshold_2 = df[f"{measurement}_2"].apply(threshold_func)
    threshold_3 = df[f"{measurement}_3"].apply(threshold_func)

    # Compute per-participant agreement
    df[f"{measurement}_Agreement"] = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold_1) & 
                                      (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold_2) & 
                                      (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold_3))

    # Compute the overall agreement percentage
    agreement_percentage = (df[f"{measurement}_Agreement"].sum() / len(df)) * 100

    # MAD calculation (Mean Absolute Difference per participant)
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3

    mean_absolute_diff = mad_per_participant.mean()  # Final MAD across all participants
    std_dev_errors = mad_per_participant.std()  # Standard deviation of MAD values

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute metrics for Heart Rate using the manufacturer's accuracy threshold
hr_agreement, hr_mad, hr_std_dev = compute_metrics(df, "HR", dynamic_hr_threshold)

# Compute agreement using clinically acceptable threshold
hr_agreement_clinical, hr_mad_clinical, hr_std_dev_clinical = compute_metrics(df, "HR", clinical_hr_threshold)

# 🔹 Print results
print("\n✅ Measurement Agreement Results (Using Manufacturer's Accuracy Threshold for Heart Rate):")
print(f"Heart Rate Agreement: {hr_agreement:.2f}%")
print(f"Mean Absolute Difference (MAD): {hr_mad:.2f} bpm")
print(f"Standard Deviation of Errors: {hr_std_dev:.2f} bpm")

print("\n✅ Measurement Agreement Results (Using Clinically Acceptable Threshold for Heart Rate):")
print(f"Heart Rate Agreement (Clinical): {hr_agreement_clinical:.2f}%")
print(f"Mean Absolute Difference (MAD): {hr_mad_clinical:.2f} bpm")
print(f"Standard Deviation of Errors: {hr_std_dev_clinical:.2f} bpm")
