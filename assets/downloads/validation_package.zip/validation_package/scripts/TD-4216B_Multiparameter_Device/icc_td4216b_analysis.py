import pandas as pd
import pingouin as pg

# Load the dataset
file_path = "Multiparameter_Validation_TD4216B.xlsx"
sheet_name = "TD-4216B_Biomarker_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Define the biomarkers with their corresponding column labels
biomarkers = {
    "Glucose": ["Glucose 1 (mg/dL)", "Glucose 2 (mg/dL)", "Glucose 3 (mg/dL)"],
    "β-Ketone": ["β-Ketone 1 (mmol/L)", "β-Ketone 2 (mmol/L)", "β-Ketone 3 (mmol/L)"],
    "Total Cholesterol": ["Total Cholesterol 1 (mg/dL)", "Total Cholesterol 2 (mg/dL)", "Total Cholesterol 3 (mg/dL)"],
    "Uric Acid": ["Uric Acid 1 (mg/dL)", "Uric Acid 2 (mg/dL)", "Uric Acid 3 (mg/dL)"],
    "Lactate": ["Lactate 1 (mmol/L)", "Lactate 2 (mmol/L)", "Lactate 3 (mmol/L)"]
}

# Function to prepare the dataset for ICC analysis
def prepare_icc_data(df, measurement_name, columns):
    """
    Reshapes the dataset for ICC calculation by converting repeated measures into a long format.
    Extracts the measurement number for proper ICC structuring.
    """
    icc_data = pd.melt(df, id_vars=["Participant ID"], 
                       value_vars=columns,
                       var_name="Measurement", value_name="Value")
    
    # Extract measurement number (1, 2, or 3)
    icc_data["Measurement"] = icc_data["Measurement"].str.extract(r'(\d)').astype(int)
    
    return icc_data

# Function to compute ICC
def compute_icc(df, measurement_name, columns):
    """
    Computes the Intraclass Correlation Coefficient (ICC) for repeated biomarker measurements.
    """
    icc_data = prepare_icc_data(df, measurement_name, columns)
    icc_result = pg.intraclass_corr(data=icc_data, targets='Participant ID', raters='Measurement', ratings='Value')
    
    return icc_result

# Compute ICC for each biomarker
icc_results = {}
for biomarker, columns in biomarkers.items():
    icc_results[biomarker] = compute_icc(df, biomarker, columns)

# Display results
print("\n✅ Intraclass Correlation Coefficient (ICC) Results for TD-4216B Biomarkers:\n")
for biomarker, icc_data in icc_results.items():
    print(f"\n📌 {biomarker} ICC:\n", icc_data)
