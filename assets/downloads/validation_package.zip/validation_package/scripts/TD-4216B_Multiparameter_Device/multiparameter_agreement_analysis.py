import pandas as pd
import numpy as np

# Load the dataset
file_path = "Multiparameter_Validation_TD4216B.xlsx"
sheet_name = "TD-4216B_Biomarker_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Glucose 1 (mg/dL)": "Glucose_1",
    "Glucose 2 (mg/dL)": "Glucose_2",
    "Glucose 3 (mg/dL)": "Glucose_3",
    "β-Ketone 1 (mmol/L)": "Ketone_1",
    "β-Ketone 2 (mmol/L)": "Ketone_2",
    "β-Ketone 3 (mmol/L)": "Ketone_3",
    "Total Cholesterol 1 (mg/dL)": "Cholesterol_1",
    "Total Cholesterol 2 (mg/dL)": "Cholesterol_2",
    "Total Cholesterol 3 (mg/dL)": "Cholesterol_3",
    "Uric Acid 1 (mg/dL)": "UricAcid_1",
    "Uric Acid 2 (mg/dL)": "UricAcid_2",
    "Uric Acid 3 (mg/dL)": "UricAcid_3",
    "Lactate 1 (mmol/L)": "Lactate_1",
    "Lactate 2 (mmol/L)": "Lactate_2",
    "Lactate 3 (mmol/L)": "Lactate_3",
})

# Define the dynamic threshold functions for each biomarker
def dynamic_glucose_threshold(value):
    """Glucose meters follow ISO 15197:2013, requiring:
       - ±15% for values ≥100 mg/dL
       - ±15 mg/dL for values <100 mg/dL
    """
    if value >= 100:
        return value * 0.15  # ±15% of the reading
    else:
        return 15  # Fixed ±15 mg/dL

def dynamic_ketone_threshold(value):
    """β-Ketone meters typically have ±0.1 to 0.2 mmol/L accuracy."""
    return 0.2  # Fixed ±0.2 mmol/L threshold

def dynamic_cholesterol_threshold(value):
    """Cholesterol meters have an expected ±3-5% error margin."""
    return value * 0.05  # ±5% of the reading

def dynamic_uric_acid_threshold(value):
    """Uric acid meters follow a ±0.5 to 1.0 mg/dL error range."""
    return 1.0  # Fixed ±1.0 mg/dL threshold based on industry tolerances

def dynamic_lactate_threshold(value):
    """Lactate meters follow a ±0.2-0.5 mmol/L accuracy range."""
    return 0.5  # Fixed ±0.5 mmol/L threshold based on industry tolerances

# Function to compute agreement percentage, MAD, and standard deviation of errors
def compute_metrics(df, measurement, threshold_func):
    threshold_1 = df[f"{measurement}_1"].apply(threshold_func)
    threshold_2 = df[f"{measurement}_2"].apply(threshold_func)
    threshold_3 = df[f"{measurement}_3"].apply(threshold_func)

    # Compute per-participant agreement
    df[f"{measurement}_Agreement"] = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold_1) & 
                                      (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold_2) & 
                                      (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold_3))

    # Compute the overall agreement percentage
    agreement_percentage = (df[f"{measurement}_Agreement"].sum() / len(df)) * 100

    # MAD calculation (mean absolute difference per participant)
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3

    mean_absolute_diff = mad_per_participant.mean()  # Final MAD across all participants

    # Standard deviation of errors per participant
    std_dev_errors = mad_per_participant.std()  # Standard deviation of the MAD values

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute agreement and MAD for all biomarkers
results = {}

for biomarker, threshold_func in zip(
    ["Glucose", "Ketone", "Cholesterol", "UricAcid", "Lactate"],
    [dynamic_glucose_threshold, dynamic_ketone_threshold, dynamic_cholesterol_threshold, dynamic_uric_acid_threshold, dynamic_lactate_threshold]
):
    agreement, mad, std_dev = compute_metrics(df, biomarker, threshold_func)
    results[biomarker] = {"Agreement": agreement, "MAD": mad, "Std Dev": std_dev}

# Print results
print("\n✅ Measurement Agreement Results:")
for biomarker, metrics in results.items():
    print(f"\n📌 {biomarker} Agreement: {metrics['Agreement']:.2f}%")
    print(f"   - Mean Absolute Difference (MAD): {metrics['MAD']:.2f}")
    print(f"   - Standard Deviation of Errors: {metrics['Std Dev']:.2f}")

