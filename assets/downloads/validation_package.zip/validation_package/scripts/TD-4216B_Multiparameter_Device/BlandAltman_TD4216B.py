import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the dataset
file_path = "Multiparameter_Validation_TD4216B.xlsx"
sheet_name = "TD-4216B_BlandAltman_Reference" 
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Define biomarkers and corresponding columns
biomarkers = {
    "Glucose": ["Glucose 1 (mg/dL)", "Glucose 2 (mg/dL)", "Glucose 3 (mg/dL)", "Glucose Reference (mg/dL)"],
    "β-Ketone": ["β-Ketone 1 (mmol/L)", "β-Ketone 2 (mmol/L)", "β-Ketone 3 (mmol/L)", "β-Ketone Reference (mmol/L)"],
    "Total Cholesterol": ["Total Cholesterol 1 (mg/dL)", "Total Cholesterol 2 (mg/dL)", "Total Cholesterol 3 (mg/dL)", "Total Cholesterol Reference (mg/dL)"],
    "Uric Acid": ["Uric Acid 1 (mg/dL)", "Uric Acid 2 (mg/dL)", "Uric Acid 3 (mg/dL)", "Uric Acid Reference (mg/dL)"],
    "Lactate": ["Lactate 1 (mmol/L)", "Lactate 2 (mmol/L)", "Lactate 3 (mmol/L)", "Lactate Reference (mmol/L)"]
}

# Prepare storage for Bland-Altman statistical results
results = []

# Function to generate Bland-Altman plots
def bland_altman_plot(biomarker, save_path, unit):
    """
    Generates a Bland-Altman plot comparing the mean of device readings with the reference value.
    """
    # Compute the mean of the three device readings per participant
    mean_device_readings = df[[biomarkers[biomarker][0], biomarkers[biomarker][1], biomarkers[biomarker][2]]].mean(axis=1)
    
    # Extract the reference values
    reference_values = df[biomarkers[biomarker][3]]

    # Compute the means and differences
    mean_values = (mean_device_readings + reference_values) / 2
    differences = mean_device_readings - reference_values

    # Compute mean difference and limits of agreement (LOA)
    mean_diff = np.mean(differences)
    std_diff = np.std(differences, ddof=1)  # Standard deviation with degrees of freedom = 1
    loa_upper = mean_diff + 1.96 * std_diff
    loa_lower = mean_diff - 1.96 * std_diff

    # Print Bland-Altman statistics
    print(f"\nBland-Altman Analysis for {biomarker}:")
    print(f"Mean Difference: {mean_diff:.2f} {unit}")
    print(f"Standard Deviation: {std_diff:.2f} {unit}")
    print(f"Upper Limit of Agreement (LOA): {loa_upper:.2f} {unit}")
    print(f"Lower Limit of Agreement (LOA): {loa_lower:.2f} {unit}")

    # Store results for saving later
    results.append({
        "Biomarker": biomarker,
        f"Mean Difference ({unit})": mean_diff,
        f"Standard Deviation ({unit})": std_diff,
        f"Upper LOA ({unit})": loa_upper,
        f"Lower LOA ({unit})": loa_lower
    })

    # Plot
    plt.figure(figsize=(8, 6))
    sns.scatterplot(x=mean_values, y=differences, alpha=0.7)
    plt.axhline(mean_diff, color='red', linestyle='--', label=f'Mean Diff: {mean_diff:.2f} {unit}')
    plt.axhline(loa_upper, color='blue', linestyle='--', label=f'Upper LOA: {loa_upper:.2f} {unit}')
    plt.axhline(loa_lower, color='blue', linestyle='--', label=f'Lower LOA: {loa_lower:.2f} {unit}')
    
    plt.xlabel(f'Mean of Device & Reference {biomarker} ({unit})')
    plt.ylabel(f'Difference (Device - Reference) ({unit})')
    plt.title(f'Bland-Altman Plot for {biomarker}')
    plt.legend()
    plt.grid(True)

    # Save the plot
    plt.savefig(save_path, dpi=300, bbox_inches='tight')
    print(f"Plot saved as: {save_path}")
    
    plt.close()  # Close the plot

# Run Bland-Altman analysis for all biomarkers
units = {
    "Glucose": "mg/dL",
    "β-Ketone": "mmol/L",
    "Total Cholesterol": "mg/dL",
    "Uric Acid": "mg/dL",
    "Lactate": "mmol/L"
}

for biomarker in biomarkers.keys():
    save_path = f"BlandAltman_{biomarker}.png"
    bland_altman_plot(biomarker, save_path, units[biomarker])

# Save the statistical results to a CSV file
results_df = pd.DataFrame(results)
results_df.to_csv("BlandAltman_Results_TD4216B.csv", index=False)
print("\nBland-Altman statistical results saved as 'BlandAltman_Results_TD4216B.csv'")
