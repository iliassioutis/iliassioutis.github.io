import matplotlib.pyplot as plt
import numpy as np

# ICC results for each biomarker from the TD-4216B analysis
biomarker_icc_results = {
    "Glucose": {
        "icc_values": [0.9527, 0.9528, 0.9549, 0.9837, 0.9837, 0.9845],
        "ci_lower": [0.91, 0.91, 0.91, 0.97, 0.97, 0.97],
        "ci_upper": [0.98, 0.98, 0.98, 0.99, 0.99, 0.99]
    },
    "β-Ketone": {
        "icc_values": [0.8820, 0.8823, 0.8889, 0.9573, 0.9574, 0.9600],
        "ci_lower": [0.78, 0.78, 0.79, 0.92, 0.91, 0.92],
        "ci_upper": [0.94, 0.94, 0.95, 0.98, 0.98, 0.98]
    },
    "Total Cholesterol": {
        "icc_values": [0.9968, 0.9968, 0.9967, 0.9989, 0.9989, 0.9989],
        "ci_lower": [0.99, 0.99, 0.99, 1.00, 1.00, 1.00],
        "ci_upper": [1.00, 1.00, 1.00, 1.00, 1.00, 1.00]
    },
    "Uric Acid": {
        "icc_values": [0.9136, 0.9135, 0.9106, 0.9694, 0.9694, 0.9683],
        "ci_lower": [0.84, 0.84, 0.83, 0.94, 0.94, 0.94],
        "ci_upper": [0.96, 0.96, 0.96, 0.99, 0.99, 0.99]
    },
    "Lactate": {
        "icc_values": [0.9042, 0.9044, 0.9099, 0.9659, 0.9659, 0.9681],
        "ci_lower": [0.82, 0.82, 0.83, 0.93, 0.93, 0.94],
        "ci_upper": [0.95, 0.95, 0.96, 0.98, 0.98, 0.99]
    }
}

# ICC type labels
icc_types = [
    "Single Measure (ICC1)", "Single Random (ICC2)", "Single Fixed (ICC3)",
    "Avg Measure (ICC1k)", "Avg Random (ICC2k)", "Avg Fixed (ICC3k)"
]

# Function to plot ICC bar charts for each biomarker
def plot_icc_chart(biomarker, icc_values, ci_lower, ci_upper):
    y_pos = np.arange(len(icc_types))
    icc_values = np.array(icc_values)
    ci_lower = np.array(ci_lower)
    ci_upper = np.array(ci_upper)

    # Compute error bars (difference between ICC and confidence intervals)
    errors = np.abs(np.array([
        icc_values - ci_lower,  # Difference between ICC and lower CI
        ci_upper - icc_values   # Difference between ICC and upper CI
    ]))

    # Create the horizontal bar chart
    plt.figure(figsize=(10, 6))
    plt.barh(y_pos, icc_values, xerr=errors, align='center', alpha=0.7, capsize=5,
             color='royalblue', edgecolor='black')

    plt.yticks(y_pos, icc_types)
    plt.xlabel("Intraclass Correlation Coefficient (ICC)")
    plt.title(f"Reliability Analysis of {biomarker} Measurements (TD-4216B)")
    plt.xlim(0.40, 1.00)  # Focus range for ICC values

    # Add grid and threshold line
    plt.grid(axis='x', linestyle='--', alpha=0.6)
    plt.axvline(x=0.75, color='orange', linestyle='--', label="Acceptable Reliability Threshold")
    plt.axvline(x=0.90, color='red', linestyle='--', label="Excellent Reliability Threshold")
    plt.legend()

    # Save and display the chart
    file_name = f"ICC_{biomarker.replace(' ', '_')}_TD4216B.png"
    plt.savefig(file_name, dpi=300, bbox_inches='tight')
    plt.show()

    print(f"✅ ICC {biomarker} Bar Chart saved as '{file_name}'")

# Generate plots for each biomarker
for biomarker, results in biomarker_icc_results.items():
    plot_icc_chart(biomarker, results["icc_values"], results["ci_lower"], results["ci_upper"])
