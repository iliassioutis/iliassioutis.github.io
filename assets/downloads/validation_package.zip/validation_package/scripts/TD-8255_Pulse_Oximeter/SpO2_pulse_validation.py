import pandas as pd
import numpy as np

# Load the dataset
file_path = "SpO2_Pulse_Validation.xlsx"
sheet_name = "TD-8255_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "SpO₂ 1 (%)": "SpO2_1",
    "SpO₂ 2 (%)": "SpO2_2",
    "SpO₂ 3 (%)": "SpO2_3",
    "Pulse 1 (bpm)": "Pulse_1",
    "Pulse 2 (bpm)": "Pulse_2",
    "Pulse 3 (bpm)": "Pulse_3",
})

# Define the dynamic threshold function for SpO2 based on manufacturer claims
def dynamic_spo2_threshold(value):
    """Dynamic threshold for SpO2 based on manufacturer accuracy claims."""
    if value >= 80:
        return 2  # ±2 percentage points
    elif 70 <= value < 80:
        return 3  # ±3 percentage points
    else:
        return None  # Undefined accuracy for SpO2 <70%

# Define a clinically acceptable threshold for pulse rate
def clinical_pulse_threshold(value):
    """Sets a clinically acceptable threshold for Pulse Rate (±3 bpm)."""
    return 3  # Fixed ±3 bpm threshold

# Function to compute agreement percentage, MAD, and standard deviation
def compute_agreement_mad_std(df, measurement, threshold_func):
    """Computes agreement, MAD, and standard deviation."""
    # Apply the threshold function to each value for dynamic SpO2 threshold
    threshold_1 = df[f"{measurement}_1"].apply(threshold_func)
    threshold_2 = df[f"{measurement}_2"].apply(threshold_func)
    threshold_3 = df[f"{measurement}_3"].apply(threshold_func)

    # Calculate per-participant agreement based on threshold
    agreement_condition = (
        (abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold_1) & 
        (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold_2) & 
        (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold_3)
    )
    
    # Compute the agreement percentage
    agreement_percentage = (agreement_condition.sum() / len(df)) * 100

    # Mean Absolute Difference (MAD) calculation
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3

    # Final MAD and standard deviation
    mean_absolute_diff = mad_per_participant.mean()
    std_dev_errors = mad_per_participant.std()

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute metrics for SpO2 using dynamic threshold
spo2_agreement, spo2_mad, spo2_std_dev = compute_agreement_mad_std(df, "SpO2", dynamic_spo2_threshold)

# Compute metrics for Pulse Rate using the clinically acceptable threshold
pulse_agreement, pulse_mad, pulse_std_dev = compute_agreement_mad_std(df, "Pulse", clinical_pulse_threshold)

# Print results
print("Measurement Agreement Results (Using Manufacturer's Accuracy Threshold for SpO₂ and Clinically Acceptable Threshold for Pulse Rate):")
print(f"SpO₂ Agreement: {spo2_agreement:.2f}% | MAD: {spo2_mad:.2f}% | Std Dev: {spo2_std_dev:.2f}%")
print(f"Pulse Rate Agreement: {pulse_agreement:.2f}% | MAD: {pulse_mad:.2f} bpm | Std Dev: {pulse_std_dev:.2f} bpm")
