import matplotlib.pyplot as plt
import numpy as np

# ICC models for Pulse Rate
icc_types = [
    "Single Measure (ICC1)", "Single Random (ICC2)", "Single Fixed (ICC3)",
    "Avg Measure (ICC1k)", "Avg Random (ICC2k)", "Avg Fixed (ICC3k)"
]

# ICC values from the output
icc_values = [0.986138, 0.986137, 0.985903, 0.995336, 0.995336, 0.995256]  # ICC values for each model
ci_lower = [0.97, 0.97, 0.97, 0.99, 0.99, 0.99]  # Lower bound of CI
ci_upper = [0.99, 0.99, 0.99, 1.00, 1.00, 1.00]  # Upper bound of CI

# Convert to NumPy arrays for plotting
y_pos = np.arange(len(icc_types))

# Compute error bars
ci_lower = np.array(ci_lower)
ci_upper = np.array(ci_upper)
icc_values = np.array(icc_values)

errors = np.abs(np.array([  # Compute error bars for plotting
    icc_values - ci_lower,  # Difference between ICC and lower CI
    ci_upper - icc_values   # Difference between ICC and upper CI
]))

# Create the bar chart
plt.figure(figsize=(10, 6))
plt.barh(y_pos, icc_values, xerr=errors, align='center', alpha=0.7, capsize=5, 
         color='royalblue', edgecolor='black')

plt.yticks(y_pos, icc_types)
plt.xlabel("Intraclass Correlation Coefficient (ICC)")
plt.title("Reliability Analysis of Pulse Rate Measurements (TaiDoc TD-8255)")
plt.xlim(0.85, 1.0)  # Focus range for ICC values

# Add grid and threshold line
plt.grid(axis='x', linestyle='--', alpha=0.6)
plt.axvline(x=0.90, color='red', linestyle='--', label="Excellent Reliability Threshold")
plt.legend()

# Save and display the chart
plt.savefig("ICC_Pulse_Rate_TD8255.png", dpi=300, bbox_inches='tight')
plt.show()

print("✅ ICC Pulse Rate Bar Chart saved as 'ICC_Pulse_Rate_TD8255.png'")