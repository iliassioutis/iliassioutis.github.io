import pandas as pd
import pingouin as pg

# Load the dataset
file_path = "Weight_Validation_TD2555.xlsx"
sheet_name = "TD-2555_Weight_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns to avoid spaces and special characters
df.columns = ["Participant_ID", "Weight_1", "Weight_2", "Weight_3"]

# Function to prepare the dataset for ICC analysis
def prepare_icc_data(df, measurement_name):
    """
    Reshapes the dataset for ICC calculation by converting repeated measures into a long format.
    Extracts the measurement number for proper ICC structuring.
    """
    icc_data = pd.melt(df, id_vars=["Participant_ID"], 
                       value_vars=[f"{measurement_name}_1", f"{measurement_name}_2", f"{measurement_name}_3"],
                       var_name="Measurement", value_name="Value")
    
    # Extract measurement number (1, 2, or 3)
    icc_data["Measurement"] = icc_data["Measurement"].str.extract(r'(\d)').astype(int)
    
    return icc_data

# Function to compute ICC
def compute_icc(df, measurement_name):
    """
    Computes the Intraclass Correlation Coefficient (ICC) for repeated weight measurements.
    """
    icc_data = prepare_icc_data(df, measurement_name)
    icc_result = pg.intraclass_corr(data=icc_data, targets='Participant_ID', raters='Measurement', ratings='Value')
    
    return icc_result

# Compute ICC for Weight measurements
icc_weight = compute_icc(df, "Weight")

# Display results
print("Intraclass Correlation Coefficient (ICC) Results:")
print("\nWeight ICC:\n", icc_weight)
