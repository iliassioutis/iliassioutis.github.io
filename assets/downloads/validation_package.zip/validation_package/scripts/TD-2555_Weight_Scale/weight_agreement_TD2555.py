import pandas as pd
import numpy as np

# Load the dataset
file_path = "Weight_Validation_TD2555.xlsx"
sheet_name = "TD-2555_Weight_Readings"
df = pd.read_excel(file_path, sheet_name=sheet_name)

# Rename columns for consistency
df = df.rename(columns={
    "Participant ID": "Participant_ID",
    "Weight 1 (kg)": "Weight_1",
    "Weight 2 (kg)": "Weight_2",
    "Weight 3 (kg)": "Weight_3",
})

# Define the dynamic threshold function based on manufacturer accuracy claims
def dynamic_weight_threshold(value):
    """Dynamic threshold for weight based on manufacturer accuracy claims."""
    if 4.0 <= value <= 60.0:
        return 0.3  # ±0.3 kg for 4.0 kg to 60.0 kg
    elif 60.1 <= value <= 250.0:
        return value * 0.005  # ±0.5% of the measured weight
    else:
        return None  # Undefined accuracy for weights outside the range

# Function to compute agreement percentage, MAD, and standard deviation of errors
def compute_metrics(df, measurement, threshold_func):
    threshold_1 = df[f"{measurement}_1"].apply(threshold_func)
    threshold_2 = df[f"{measurement}_2"].apply(threshold_func)
    threshold_3 = df[f"{measurement}_3"].apply(threshold_func)

    # Compute per-participant agreement
    df[f"{measurement}_Agreement"] = ((abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) <= threshold_1) & 
                                      (abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) <= threshold_2) & 
                                      (abs(df[f"{measurement}_1"] - df[f"{measurement}_3"]) <= threshold_3))

    # Compute the overall agreement percentage
    agreement_percentage = (df[f"{measurement}_Agreement"].sum() / len(df)) * 100

    # MAD calculation (Mean Absolute Difference per participant)
    mad_per_participant = (
        abs(df[f"{measurement}_1"] - df[f"{measurement}_2"]) +
        abs(df[f"{measurement}_2"] - df[f"{measurement}_3"]) +
        abs(df[f"{measurement}_1"] - df[f"{measurement}_3"])
    ) / 3

    mean_absolute_diff = mad_per_participant.mean()  # Final MAD across all participants
    std_dev_errors = mad_per_participant.std()  # Standard deviation of MAD values

    return agreement_percentage, mean_absolute_diff, std_dev_errors

# Compute metrics for Weight using the manufacturer's accuracy threshold
weight_agreement, weight_mad, weight_std_dev = compute_metrics(df, "Weight", dynamic_weight_threshold)

# 🔹 Print results
print("\n✅ Measurement Agreement Results (Using Manufacturer's Accuracy Threshold for Weight):")
print(f"Weight Agreement: {weight_agreement:.2f}%")
print(f"Mean Absolute Difference (MAD): {weight_mad:.2f} kg")
print(f"Standard Deviation of Errors: {weight_std_dev:.2f} kg")
