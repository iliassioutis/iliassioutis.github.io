import matplotlib.pyplot as plt
import numpy as np

# ICC values for Weight Measurements (TD-2555)
icc_types = [
    "Single Measure (ICC1)", "Single Random (ICC2)", "Single Fixed (ICC3)",
    "Avg Measure (ICC1k)", "Avg Random (ICC2k)", "Avg Fixed (ICC3k)"
]

icc_values = [0.999921, 0.999921, 0.999919, 0.999974, 0.999974, 0.999973]  # ICC values from analysis
ci_lower = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]  # Lower bound of CI
ci_upper = [1.0, 1.0, 1.0, 1.0, 1.0, 1.0]  # Upper bound of CI

# Convert lists to NumPy arrays for calculations
y_pos = np.arange(len(icc_types))
icc_values = np.array(icc_values)
ci_lower = np.array(ci_lower)
ci_upper = np.array(ci_upper)

# Ensure confidence intervals are correctly represented
errors = np.abs(np.array([
    icc_values - ci_lower,  # Lower confidence bound
    ci_upper - icc_values   # Upper confidence bound
]))

# Create the horizontal bar chart with confidence intervals
plt.figure(figsize=(10, 6))
plt.barh(y_pos, icc_values, xerr=errors, align='center', alpha=0.7, capsize=8,
         color='royalblue', edgecolor='black', error_kw=dict(ecolor='black', capthick=3))

plt.yticks(y_pos, icc_types)
plt.xlabel("Intraclass Correlation Coefficient (ICC)")
plt.title("Reliability Analysis of Weight Measurements (TD-2555)")
plt.xlim(0.899, 1)

# Add grid and threshold line at 0.90
plt.grid(axis='x', linestyle='--', alpha=0.6)
plt.axvline(x=0.90, color='red', linestyle='--', linewidth=2, label="Excellent Reliability Threshold (0.90)")
plt.legend()

# Save and display the chart
plt.savefig("ICC_Weight_TD2555.png", dpi=300, bbox_inches='tight')
plt.show()

print("✅ ICC Weight Bar Chart saved as 'ICC_Weight_TD2555.png'")
